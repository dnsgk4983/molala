
import { useEffect, useState } from 'react';
import LoadingPage from './pages/LoadingPage.jsx';
import TitlePage from './pages/TitlePage.jsx';
import ProloguePage from './pages/ProloguePage.jsx';
import ChatPage from './pages/ChatPage.jsx';
import EndingPage from './pages/EndingPage.jsx';
import CookiePage from './pages/CookiePage.jsx';
import { load_game } from './utils/save_game.js';

const SAVE_KEY = 'morara_save_v1';

const PAGE = {
    LOADING: 'loading',
    TITLE: 'title',
    PROLOGUE: 'prologue',
    CHAT: 'chat',
    ENDING: 'ending',
    COOKIE: 'cookie'
};

function get_initial_page() {
    const game_data = load_game();

    if (game_data?.is_finished) {
        return PAGE.ENDING;
    }

    return PAGE.LOADING;
}

function App() {
    const [current_page, set_current_page] = useState(get_initial_page);

    useEffect(() => {
        if (current_page !== PAGE.CHAT) {
            return;
        }

        const check_game_completion = () => {
            const game_data = load_game();

            if (game_data?.is_finished) {
                set_current_page(PAGE.ENDING);
            }
        };

        check_game_completion();

        const interval_id = window.setInterval(
            check_game_completion,
            300
        );

        return () => {
            window.clearInterval(interval_id);
        };
    }, [current_page]);

    const handle_loading_complete = () => {
        set_current_page(PAGE.TITLE);
    };

    const handle_start = () => {
        const game_data = load_game();

        if (game_data?.is_finished) {
            set_current_page(PAGE.ENDING);
            return;
        }

        const has_progress = (
            Number(game_data?.day) > 1 ||
            Number(game_data?.step) > 0 ||
            (
                Array.isArray(game_data?.messages) &&
                game_data.messages.length > 0
            )
        );

        if (has_progress) {
            set_current_page(PAGE.CHAT);
            return;
        }

        set_current_page(PAGE.PROLOGUE);
    };

    const handle_prologue_complete = () => {
        set_current_page(PAGE.CHAT);
    };

    const handle_ending_complete = () => {
        set_current_page(PAGE.COOKIE);
    };

    const handle_cookie_complete = () => {
        window.localStorage.removeItem(SAVE_KEY);
        set_current_page(PAGE.TITLE);
    };

    const render_page = () => {
        switch (current_page) {
            case PAGE.LOADING:
                return (
                    <LoadingPage
                        on_complete={handle_loading_complete}
                    />
                );

            case PAGE.TITLE:
                return (
                    <TitlePage
                        on_start={handle_start}
                    />
                );

            case PAGE.PROLOGUE:
                return (
                    <ProloguePage
                        on_complete={handle_prologue_complete}
                    />
                );

            case PAGE.CHAT:
                return <ChatPage />;

            case PAGE.ENDING:
                return (
                    <EndingPage
                        on_restart={handle_ending_complete}
                    />
                );

            case PAGE.COOKIE:
                return (
                    <CookiePage
                        on_complete={handle_cookie_complete}
                    />
                );

            default:
                return (
                    <LoadingPage
                        on_complete={handle_loading_complete}
                    />
                );
        }
    };

    return render_page();
}

export default App;
