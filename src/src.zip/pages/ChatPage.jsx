
import { useCallback, useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { story_data, last_day } from '../data/story_data.js';
import { load_game, save_game } from '../utils/save_game.js';

const speed_options = {
    fast: 450,
    normal: 1100,
    slow: 1800
};

const image_modules = import.meta.glob(
    '../assets/images/**/*.{png,jpg,jpeg,webp}',
    {
        eager: true,
        query: '?url',
        import: 'default'
    }
);

const image_map = Object.fromEntries(
    Object.entries(image_modules).map(([path, url]) => [
        path.split('/').pop(),
        url
    ])
);

function get_profile_image(day) {
    const image_name = day >= 4
        ? 'day03_selfie.png'
        : 'profile_sunfish.png';

    return image_map[image_name];
}

function get_initial_state() {
    const saved_data = load_game();

    if (saved_data?.current_page === 'chat') {
        const saved_day = Number.isInteger(saved_data.day)
            ? Math.min(Math.max(saved_data.day, 1), last_day)
            : 1;

        const saved_messages = Array.isArray(saved_data.messages)
            ? saved_data.messages.filter(
                (message) => (
                    message &&
                    typeof message.text === 'string' &&
                    [
                        'morara',
                        'player',
                        'system',
                        'narration',
                        'image',
                        'music'
                    ].includes(message.sender)
                )
            )
            : [];

        const saved_step = Number.isInteger(saved_data.step)
            ? Math.min(
                Math.max(saved_data.step, 0),
                story_data[saved_day].length
            )
            : 0;

        let saved_reply_queue = [];

        if (Array.isArray(saved_data.reply_queue)) {
            saved_reply_queue = saved_data.reply_queue.filter(
                (text) => typeof text === 'string'
            );
        } else if (typeof saved_data.pending_reply === 'string') {
            saved_reply_queue = saved_data.pending_reply.split('\n');
        }

        return {
            day: saved_day,
            step: saved_step,
            messages: saved_messages,
            affection: Number.isFinite(saved_data.affection)
                ? saved_data.affection
                : 0,
            message_speed: speed_options[saved_data.message_speed]
                ? saved_data.message_speed
                : 'normal',
            reply_queue: saved_reply_queue,
            choice_pending: (
                saved_data.choice_pending === true ||
                saved_reply_queue.length > 0
            )
        };
    }

    return {
        day: 1,
        step: 0,
        messages: [],
        affection: 0,
        message_speed: 'normal',
        reply_queue: [],
        choice_pending: false
    };
}

function ChatPage() {
    const initial_state_ref = useRef(null);

    if (initial_state_ref.current === null) {
        initial_state_ref.current = get_initial_state();
    }

    const [game_state, set_game_state] = useState(
        initial_state_ref.current
    );

    const [reaction, set_reaction] = useState(null);
    const [is_settings_open, set_is_settings_open] = useState(false);
    const [day_transition, set_day_transition] = useState(null);

    const scroll_ref = useRef(null);
    const last_scrolled_message_ref = useRef(null);
    const reaction_ref = useRef(null);
    const tiara_light_ref = useRef(null);
    const tiara_glow_ref = useRef(null);
    const tiara_progress_ref = useRef(null);
    const timer_ref = useRef(null);
    const transition_timer_ref = useRef([]);
    const pending_action_ref = useRef(null);
    const choice_locked_ref = useRef(false);
    const state_ref = useRef(game_state);

    const message_id_ref = useRef(
        game_state.messages.reduce(
            (maximum, message) => Math.max(
                maximum,
                Number(message.id) || 0
            ),
            0
        ) + 1
    );

    state_ref.current = game_state;

    const {
        day,
        step,
        messages,
        affection,
        message_speed,
        reply_queue,
        choice_pending
    } = game_state;

    const current_story = story_data[day] ?? [];
    const current_step = current_story[step];

    const day_progress = current_story.length > 0
        ? Math.min(step / current_story.length, 1)
        : 0;
    const tiara_progress = Math.min(
        Math.max(((day - 1) + day_progress) / last_day, 0),
        1
    );

    useEffect(() => {
        const tiara_light = tiara_light_ref.current;
        const tiara_glow = tiara_glow_ref.current;

        if (!tiara_light || !tiara_glow) {
            return;
        }

        const previous_progress = tiara_progress_ref.current;
        const next_progress = tiara_progress;
        const mask_at = (progress) => {
            const top = Math.max(0, Math.min(100, 110 * progress - 5));
            const bottom = Math.max(0, Math.min(100, 110 * progress + 5));

            return `polygon(0 0, ${top}% 0, ${bottom}% 100%, 0 100%)`;
        };

        if (previous_progress === null) {
            gsap.set(tiara_light, {
                clipPath: mask_at(next_progress)
            });
        } else {
            gsap.fromTo(
                tiara_light,
                {
                    clipPath: mask_at(previous_progress)
                },
                {
                    clipPath: mask_at(next_progress),
                    duration: 1.4,
                    ease: 'power2.inOut',
                    overwrite: true
                }
            );
        }

        tiara_progress_ref.current = next_progress;

        const glow_animation = gsap.to(tiara_glow, {
            opacity: 0.65,
            duration: 1.8,
            ease: 'sine.inOut',
            repeat: -1,
            yoyo: true
        });

        return () => {
            glow_animation.kill();
            gsap.killTweensOf(tiara_light);
        };
    }, [tiara_progress]);

    const is_choice = current_step?.type === 'choice';
    const is_day_complete = !current_step && !choice_pending;
    const is_game_complete = is_day_complete && day === last_day;

    const is_typing = (
        choice_pending && reply_queue.length > 0
    ) || current_step?.type === 'message';

    const clear_pending = useCallback(() => {
        if (timer_ref.current !== null) {
            clearTimeout(timer_ref.current);
            timer_ref.current = null;
        }

        pending_action_ref.current = null;
    }, []);

    const run_pending = useCallback(() => {
        const action = pending_action_ref.current;

        if (!action) {
            return;
        }

        clear_pending();
        action();
    }, [clear_pending]);

    const schedule_action = useCallback((action, delay) => {
        clear_pending();

        pending_action_ref.current = action;

        timer_ref.current = setTimeout(() => {
            run_pending();
        }, delay);
    }, [clear_pending, run_pending]);

    const update_game = useCallback((updater) => {
        const next_state = updater(state_ref.current);

        state_ref.current = next_state;

        save_game({
            ...next_state,
            current_page: 'chat',
            pending_reply: null,
            is_finished: (
                next_state.day === last_day &&
                next_state.step >= story_data[last_day].length &&
                !next_state.choice_pending
            )
        });

        set_game_state(next_state);
    }, []);

    useEffect(() => {
        return () => {
            clear_pending();
            transition_timer_ref.current.forEach(clearTimeout);
        };
    }, [clear_pending]);

    useEffect(() => {
        save_game({
            ...state_ref.current,
            current_page: 'chat',
            pending_reply: null,
            is_finished: is_game_complete
        });
    }, [is_game_complete]);

    useEffect(() => {
        if (is_day_complete) {
            return;
        }

        if (choice_pending) {
            if (reply_queue.length === 0) {
                update_game((previous) => ({
                    ...previous,
                    choice_pending: false,
                    step: previous.step + 1
                }));

                choice_locked_ref.current = false;
                return;
            }

            schedule_action(() => {
                update_game((previous) => ({
                    ...previous,
                    messages: [
                        ...previous.messages,
                        {
                            id: message_id_ref.current++,
                            sender: 'morara',
                            text: previous.reply_queue[0],
                            day: previous.day
                        }
                    ],
                    reply_queue: previous.reply_queue.slice(1)
                }));
            }, speed_options[message_speed]);

            return clear_pending;
        }

        if (current_step?.type === 'choice') {
            return;
        }

        if (current_step) {
            schedule_action(() => {
                update_game((previous) => ({
                    ...previous,
                    messages: [
                        ...previous.messages,
                        {
                            id: message_id_ref.current++,
                            sender: current_step.type === 'message'
                                ? current_step.sender
                                : current_step.type,
                            text: current_step.text ?? '',
                            image: current_step.image ?? null,
                            title: current_step.title ?? null,
                            day: previous.day
                        }
                    ],
                    step: previous.step + 1
                }));
            }, speed_options[message_speed]);

            return clear_pending;
        }
    }, [
        day,
        step,
        choice_pending,
        reply_queue,
        message_speed,
        current_step,
        is_day_complete,
        schedule_action,
        clear_pending,
        update_game
    ]);

    useEffect(() => {
        const container = scroll_ref.current;

        if (!container || messages.length === 0) {
            return;
        }

        const latest_message = messages[messages.length - 1];

        if (last_scrolled_message_ref.current === latest_message.id) {
            return;
        }

        last_scrolled_message_ref.current = latest_message.id;

        if (latest_message.sender === 'image') {
            const image_event = Array.from(
                container.querySelectorAll('.chat_page__image_event')
            ).at(-1);

            if (image_event) {
                const container_rect = container.getBoundingClientRect();
                const image_rect = image_event.getBoundingClientRect();
                const target_top = container.scrollTop + image_rect.top - container_rect.top;

                container.scrollTo({
                    top: target_top - 16,
                    behavior: 'smooth'
                });
            }

            return;
        }

        container.scrollTo({
            top: container.scrollHeight,
            behavior: 'smooth'
        });
    }, [messages]);

    useEffect(() => {
        if (!reaction || !reaction_ref.current) {
            return;
        }

        const animation = gsap.fromTo(
            reaction_ref.current,
            {
                opacity: 0,
                y: 0,
                scale: 0.7
            },
            {
                opacity: 1,
                y: -35,
                scale: 1.2,
                duration: 0.7,
                ease: 'power2.out',
                onComplete: () => {
                    set_reaction(null);
                }
            }
        );

        return () => {
            animation.kill();
        };
    }, [reaction]);

    const handle_skip = () => {
        if (is_settings_open || is_day_complete) {
            return;
        }

        run_pending();
    };

    const handle_choice = (option) => {
        if (
            choice_locked_ref.current ||
            !is_choice ||
            choice_pending
        ) {
            return;
        }

        choice_locked_ref.current = true;

        const replies = Array.isArray(option.reply)
            ? option.reply
            : String(option.reply ?? '').split('\n');

        const valid_replies = replies.filter(
            (text) => typeof text === 'string' && text.length > 0
        );

        update_game((previous) => ({
            ...previous,
            affection: previous.affection + option.affection,
            messages: [
                ...previous.messages,
                {
                    id: message_id_ref.current++,
                    sender: 'player',
                    text: option.text,
                    day: previous.day
                }
            ],
            reply_queue: valid_replies,
            choice_pending: true
        }));

        set_reaction({
            id: message_id_ref.current++,
            emoji: option.reaction,
            value: option.affection
        });
    };

    const handle_next_day = () => {
        if (day_transition || !is_day_complete || is_game_complete) {
            return;
        }

        clear_pending();
        const next_day = day + 1;
        set_day_transition({ day: next_day, phase: 'enter' });

        const change_timer = window.setTimeout(() => {
            update_game((previous) => ({
                ...previous,
                day: next_day,
                step: 0,
                reply_queue: [],
                choice_pending: false,
                messages: [
                    ...previous.messages,
                    {
                        id: message_id_ref.current++,
                        sender: 'system',
                        text: `DAY ${next_day}`,
                        day: next_day
                    }
                ]
            }));
            set_day_transition({ day: next_day, phase: 'leave' });
        }, 1700);

        const finish_timer = window.setTimeout(() => {
            set_day_transition(null);
            transition_timer_ref.current = [];
        }, 2500);

        transition_timer_ref.current = [change_timer, finish_timer];
    };

    const handle_speed_change = (event) => {
        const next_speed = event.target.value;

        if (!speed_options[next_speed]) {
            return;
        }

        update_game((previous) => ({
            ...previous,
            message_speed: next_speed
        }));
    };

    const render_message = (message, history_day) => {
        if (message.sender === 'system') {
            return (
                <div
                    className="chat_page__date"
                    key={message.id}
                >
                    {message.text}
                </div>
            );
        }

        if (message.sender === 'narration') {
            return (
                <div
                    className="chat_page__narration"
                    key={message.id}
                >
                    {message.text}
                </div>
            );
        }

        if (message.sender === 'music') {
            return (
                <div
                    className="chat_page__music_event"
                    key={message.id}
                    aria-label="음성 파일 영역, 추후 재생 기능 추가 예정"
                >
                    <span className="chat_page__music_icon" aria-hidden="true">♫</span>
                    <div className="chat_page__music_details">
                        <strong>{message.title || '백일몽'}</strong>
                        <span>음성 파일 · 준비 중</span>
                        <div className="chat_page__music_wave" aria-hidden="true">
                            <span />
                            <span />
                            <span />
                            <span />
                            <span />
                            <span />
                            <span />
                        </div>
                    </div>
                    <span className="chat_page__music_play" aria-hidden="true">▶</span>
                </div>
            );
        }

        if (message.sender === 'image') {
            const image_url = image_map[message.image];

            return (
                <div
                    className="chat_page__image_event"
                    key={message.id}
                >
                    {image_url ? (
                        <img
                            src={image_url}
                            alt={message.text || '모라라가 보낸 사진'}
                            loading="lazy"
                        />
                    ) : (
                        <div className="chat_page__image_placeholder">
                            이미지를 찾을 수 없습니다: {message.image}
                        </div>
                    )}
                </div>
            );
        }

        return (
            <div
                className={`chat_page__message chat_page__message_${message.sender}`}
                key={message.id}
            >
                {message.sender === 'morara' && (
                    <div className="chat_page__message_avatar">
                        <img
                            src={get_profile_image(message.day ?? history_day)}
                            alt="모라라 공주님♡ 프로필"
                            style={{
                                display: 'block',
                                width: '100%',
                                height: '100%',
                                objectFit: 'cover',
                                borderRadius: '50%'
                            }}
                        />
                    </div>
                )}

                <div className="chat_page__bubble">
                    {message.text}
                </div>
            </div>
        );
    };

    return (
        <section className="chat_page" style={{ position: 'relative' }}>
            <header className="chat_page__header">
                <div className="chat_page__avatar">
                    <img
                        src={get_profile_image(day)}
                        alt="모라라 공주님♡ 프로필"
                        style={{
                            display: 'block',
                            width: '100%',
                            height: '100%',
                            objectFit: 'cover',
                            borderRadius: '50%'
                        }}
                    />
                </div>

                <div className="chat_page__profile">
                    <strong>모라라 공주님♡</strong>
                    <span>
                        1월 {day + 3}일 · DAY {day}
                    </span>
                </div>

                <div
                    className="chat_page__tiara_progress"
                    role="progressbar"
                    aria-label="티아라 빛 충전 진행도"
                    aria-valuemin={0}
                    aria-valuemax={100}
                    aria-valuenow={Math.round(tiara_progress * 100)}
                >
                    <img
                        className="chat_page__tiara_empty"
                        src={image_map['tiara_empty.png']}
                        alt=""
                        draggable={false}
                    />
                    <div
                        className="chat_page__tiara_light_mask"
                        ref={tiara_light_ref}
                    >
                        <img
                            className="chat_page__tiara_full"
                            src={image_map['tiara_full.png']}
                            alt=""
                            draggable={false}
                        />
                    </div>
                    <div
                        className="chat_page__tiara_glow"
                        ref={tiara_glow_ref}
                        aria-hidden="true"
                    />
                </div>

                <div className="chat_page__affection">
                    <span>💕</span>
                    <strong>{affection}</strong>
                </div>

                <button
                    className="chat_page__settings_button"
                    type="button"
                    aria-label="설정 열기"
                    onClick={() => set_is_settings_open(true)}
                >
                    ⚙
                </button>

                {reaction && (
                    <div
                        className="chat_page__reaction"
                        ref={reaction_ref}
                        key={reaction.id}
                    >
                        <span>{reaction.emoji}</span>
                        <small>
                            {reaction.value > 0 ? '+' : ''}
                            {reaction.value}
                        </small>
                    </div>
                )}
            </header>

            <div
                className="chat_page__messages"
                ref={scroll_ref}
                onClick={handle_skip}
            >
                {messages.map((message, index) => {
                    const previous_day_markers = messages
                        .slice(0, index + 1)
                        .filter((item) => (
                            item.sender === 'system' &&
                            /^DAY \d+$/.test(item.text)
                        ));

                    const latest_marker = previous_day_markers.at(-1);
                    const history_day = latest_marker
                        ? Number(latest_marker.text.replace('DAY ', ''))
                        : 1;

                    return render_message(message, history_day);
                })}

                {is_typing && (
                    <div className="chat_page__message chat_page__message_morara">
                        <div className="chat_page__message_avatar">
                            <img
                                src={get_profile_image(day)}
                                alt="모라라 공주님♡ 프로필"
                                style={{
                                    display: 'block',
                                    width: '100%',
                                    height: '100%',
                                    objectFit: 'cover',
                                    borderRadius: '50%'
                                }}
                            />
                        </div>

                        <div className="chat_page__bubble chat_page__typing">
                            <span />
                            <span />
                            <span />
                        </div>
                    </div>
                )}

                {is_day_complete && (
                    <div className="chat_page__end">
                        DAY {day} 종료
                    </div>
                )}
            </div>

            <footer className="chat_page__footer">
                {is_choice && !choice_pending && (
                    <div className="chat_page__choices">
                        {current_step.options.map((option) => (
                            <button
                                className="chat_page__choice"
                                type="button"
                                key={option.text}
                                onClick={() => handle_choice(option)}
                            >
                                {option.text}
                            </button>
                        ))}
                    </div>
                )}

                {is_day_complete && !is_game_complete && (
                    <button
                        className="chat_page__choice"
                        type="button"
                        onClick={handle_next_day}
                    >
                        DAY {day + 1} 시작하기
                    </button>
                )}

                {is_game_complete && (
                    <div className="chat_page__waiting">
                        현재 준비된 스토리가 모두 종료되었습니다.
                    </div>
                )}

                {!is_choice && !is_day_complete && (
                    <div className="chat_page__waiting">
                        화면을 터치하면 빠르게 진행됩니다.
                    </div>
                )}

                {choice_pending && (
                    <div className="chat_page__waiting">
                        모라라가 답장하고 있습니다...
                    </div>
                )}
            </footer>

            {day_transition && (
                <div
                    className="chat_page__day_transition"
                    role="status"
                    aria-live="polite"
                    style={{
                        position: 'absolute',
                        inset: 0,
                        zIndex: 100,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '14px',
                        background: 'linear-gradient(160deg, #231c35, #48304e)',
                        color: '#fff5fa',
                        opacity: day_transition.phase === 'leave' ? 0 : 1,
                        transition: 'opacity 0.8s ease',
                        pointerEvents: 'auto'
                    }}
                >
                    <span style={{ fontSize: '13px', letterSpacing: '0.28em' }}>
                        THE NEXT DAY
                    </span>
                    <strong style={{ fontSize: '48px', letterSpacing: '0.08em' }}>
                        DAY {String(day_transition.day).padStart(2, '0')}
                    </strong>
                    <span style={{ fontSize: '16px' }}>
                        1월 {day_transition.day + 3}일
                    </span>
                    <span aria-hidden="true" style={{ fontSize: '25px' }}>
                        ✦
                    </span>
                </div>
            )}

            {is_settings_open && (
                <div className="chat_page__settings_overlay">
                    <div
                        className="chat_page__settings_panel"
                        role="dialog"
                        aria-modal="true"
                        aria-label="대화 설정"
                    >
                        <h2>대화 설정</h2>

                        <label htmlFor="message_speed">
                            대화 속도
                        </label>

                        <select
                            id="message_speed"
                            value={message_speed}
                            onChange={handle_speed_change}
                        >
                            <option value="fast">빠르게</option>
                            <option value="normal">보통</option>
                            <option value="slow">느리게</option>
                        </select>

                        <button
                            type="button"
                            onClick={() => set_is_settings_open(false)}
                        >
                            닫기
                        </button>
                    </div>
                </div>
            )}
        </section>
    );
}

export default ChatPage;
